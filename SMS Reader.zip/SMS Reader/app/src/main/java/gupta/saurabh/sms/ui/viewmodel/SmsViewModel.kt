package gupta.saurabh.sms.ui.viewmodel

import android.content.Context
import androidx.lifecycle.*
import dagger.hilt.android.lifecycle.HiltViewModel
import gupta.saurabh.sms.data.model.SmsData
import gupta.saurabh.sms.data.repository.SmsRepository
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class SmsViewModel @Inject constructor(
    private val repository: SmsRepository
) : ViewModel() {

    val _smsList = MutableLiveData<List<SmsData>>()
    val smsList: LiveData<List<SmsData>> = _smsList

    private val _filteredSmsList = MutableLiveData<List<SmsData>>()
    val filteredSmsList: LiveData<List<SmsData>> = _filteredSmsList

    fun fetchAllSms(context: Context) {
        viewModelScope.launch {
            _smsList.postValue(repository.getAllSms(context))
        }
    }

    fun filterSmsBySender(senderId: String) {
        _filteredSmsList.postValue(_smsList.value?.filter { it.sender.contains(senderId, true) })
    }

    fun addSms(sender: String, body: String, timestamp: Long) {
        val newSms = SmsData(sender, body, timestamp)
        val updatedList = _smsList.value.orEmpty().toMutableList()
        updatedList.add(0, newSms) // Add at the top (latest SMS first)
        _smsList.value = updatedList
    }
}