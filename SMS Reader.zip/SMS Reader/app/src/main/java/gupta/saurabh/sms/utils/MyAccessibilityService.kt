package gupta.saurabh.sms.utils

import android.accessibilityservice.AccessibilityService
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class MyAccessibilityService : AccessibilityService() {

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        Log.e("TAG", "onAccessibilityEvent: ${event}")
        if (event == null) return
        if (event.packageName == "com.google.android.apps.messaging") {
            when (event.eventType) {
                AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED -> {
                    val messages = event.text
                    for (message in messages) {
                        Log.d("RCS_Message", "New RCS Message: $message")
                    }
                }
                AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED -> {
                    val source: AccessibilityNodeInfo? = event.source
                    source?.let {
                        traverseNode(it)
                    }
                }
            }
        }
    }

    private fun traverseNode(node: AccessibilityNodeInfo) {
        if (node.className == "android.widget.TextView") {
            val message = node.text?.toString() ?: return
            Log.d("RCS_Message", "Extracted RCS Message: $message")
        }

        for (i in 0 until node.childCount) {
            node.getChild(i)?.let { traverseNode(it) }
        }
    }

    override fun onInterrupt() {
        Log.d("RCS_Message", "Accessibility Service Interrupted")
    }
}