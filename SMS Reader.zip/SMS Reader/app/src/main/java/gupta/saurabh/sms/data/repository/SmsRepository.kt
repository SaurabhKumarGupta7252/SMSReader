package gupta.saurabh.sms.data.repository

import android.content.Context
import android.provider.Telephony
import gupta.saurabh.sms.data.model.SmsData
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class SmsRepository @Inject constructor() {

    suspend fun getAllSms(context: Context): List<SmsData> = withContext(Dispatchers.IO) {
        val smsList = mutableListOf<SmsData>()
//        val uri = Telephony.Sms.Inbox.CONTENT_URI
        val uri = Telephony.Sms.CONTENT_URI
        val projection = arrayOf(Telephony.Sms.ADDRESS, Telephony.Sms.BODY, Telephony.Sms.DATE)

        context.contentResolver.query(uri, projection, null, null, Telephony.Sms.DATE + " DESC")
            ?.use { cursor ->
                val indexAddress = cursor.getColumnIndex(Telephony.Sms.ADDRESS)
                val indexBody = cursor.getColumnIndex(Telephony.Sms.BODY)
                val indexDate = cursor.getColumnIndex(Telephony.Sms.DATE)

                while (cursor.moveToNext()) {
                    smsList.add(
                        SmsData(
                            sender = cursor.getString(indexAddress) ?: "Unknown",
                            body = cursor.getString(indexBody) ?: "",
                            timestamp = cursor.getLong(indexDate)
                        )
                    )
                }
            }
        return@withContext smsList
    }
}