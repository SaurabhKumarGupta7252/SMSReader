package gupta.saurabh.sms.ui.adapter


import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import gupta.saurabh.sms.R
import gupta.saurabh.sms.data.model.SmsData
import gupta.saurabh.sms.utils.DateUtils

class SmsAdapter(private var smsList: List<SmsData>) : RecyclerView.Adapter<SmsAdapter.SmsViewHolder>() {

    inner class SmsViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvSender: TextView = view.findViewById(R.id.tvSender)
        val tvMessage: TextView = view.findViewById(R.id.tvMessage)
        val tvTimestamp: TextView = view.findViewById(R.id.tvTimestamp)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SmsViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_sms, parent, false)
        return SmsViewHolder(view)
    }

    override fun onBindViewHolder(holder: SmsViewHolder, position: Int) {
        val sms = smsList[position]
        holder.tvSender.text = "From: ${sms.sender}"
        holder.tvMessage.text = sms.body
        holder.tvTimestamp.text = DateUtils.formatTimestamp(sms.timestamp)
    }

    override fun getItemCount(): Int = smsList.size

    fun updateList(newList: List<SmsData>) {
        smsList = newList
        notifyDataSetChanged()
    }
}
