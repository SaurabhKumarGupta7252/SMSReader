package gupta.saurabh.sms.utils

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import android.util.Log
import androidx.localbroadcastmanager.content.LocalBroadcastManager

class MmsReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        Log.e("TAG", "onReceive: Hii 2", )
        if (intent.action == Telephony.Sms.Intents.WAP_PUSH_RECEIVED_ACTION) {
            val contentType = intent.getStringExtra("data")
            val type = intent.getStringExtra("contentType")
            if ("application/vnd.wap.mms-message" == type) {
                Log.d("MMS_RECEIVER", "WAP Push MMS received")
            }
            if ("application/vnd.wap.mms-message" == contentType) {
                val mmsIntent = Intent("MMS_RECEIVED")
                LocalBroadcastManager.getInstance(context).sendBroadcast(mmsIntent)
            }
        }
    }
}
