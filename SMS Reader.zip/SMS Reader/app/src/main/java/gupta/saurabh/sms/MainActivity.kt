package gupta.saurabh.sms

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.database.ContentObserver
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Telephony
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import dagger.hilt.android.AndroidEntryPoint
import gupta.saurabh.sms.data.model.SmsData
import gupta.saurabh.sms.ui.adapter.SmsAdapter
import gupta.saurabh.sms.ui.viewmodel.SmsViewModel

@AndroidEntryPoint
class MainActivity : AppCompatActivity() {

    private val smsViewModel: SmsViewModel by viewModels()
    private lateinit var smsAdapter: SmsAdapter
    private lateinit var rvSmsList: RecyclerView
    private lateinit var etSenderId: EditText
    private lateinit var btnFilter: Button
    private val list = arrayListOf<SmsData>()

//    private lateinit var mmsObserver: MmsObserver

    private val smsReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {

            val sender = intent.getStringExtra("sender") ?: "Unknown"
            val message = intent.getStringExtra("message") ?: ""
            val timestamp = intent.getLongExtra("timestamp", 0)
            Log.e("TAG", "onReceive:Activity $sender $message")

            smsViewModel.addSms(sender, message, timestamp)
            smsAdapter.notifyDataSetChanged()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)

        enableEdgeToEdge()

        setContentView(R.layout.activity_main)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->

            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())

            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)

            insets
        }

        /*val handler = Handler(Looper.getMainLooper())
        mmsObserver = MmsObserver(this, handler)

        contentResolver.registerContentObserver(
            Uri.parse("content://mms/inbox"),
            true,
            mmsObserver
        )*/

        rvSmsList = findViewById(R.id.rvSmsList)
        etSenderId = findViewById(R.id.etSenderId)
        btnFilter = findViewById(R.id.btnFilter)

        // Setup RecyclerView
        smsAdapter = SmsAdapter(emptyList())
        rvSmsList.layoutManager = LinearLayoutManager(this)
        rvSmsList.adapter = smsAdapter

        checkAndRequestSmsPermissions()

        // Observe SMS list
        smsViewModel.smsList.observe(this) { smsList ->
            smsAdapter.updateList(smsList)
        }

        // Observe filtered list
        smsViewModel.filteredSmsList.observe(this) { filteredList ->
            smsAdapter.updateList(filteredList)
        }

        // Filter SMS by sender ID
        btnFilter.setOnClickListener {
            val senderId = etSenderId.text.toString()
            smsViewModel.filterSmsBySender(senderId)
        }

        LocalBroadcastManager.getInstance(this)
            .registerReceiver(smsReceiver, IntentFilter("SMS_RECEIVED"))

    }

    private fun checkAndRequestSmsPermissions() {

        if (ContextCompat.checkSelfPermission(
                this,
                android.Manifest.permission.READ_SMS
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            // Fetch all SMS when activity starts
            //smsViewModel.fetchAllSms(this)
            readSms()
        } else {
            val smsPermissions = arrayOf(
                android.Manifest.permission.READ_SMS,
                android.Manifest.permission.RECEIVE_SMS
            )

            val permissionsNeeded = smsPermissions.filter {
                ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
            }

            if (permissionsNeeded.isNotEmpty()) {
                ActivityCompat.requestPermissions(this, permissionsNeeded.toTypedArray(), 101)
            }
        }
    }

    fun readSms() {
        val contentResolver = contentResolver
        val cursor = contentResolver.query(
            Telephony.Sms.CONTENT_URI,
            arrayOf(Telephony.Sms.ADDRESS, Telephony.Sms.BODY, Telephony.Sms.DATE),
            null, null, Telephony.Sms.DEFAULT_SORT_ORDER
        )

        if (cursor != null && cursor.moveToFirst()) {
            do {
                val address = cursor.getString(cursor.getColumnIndexOrThrow(Telephony.Sms.ADDRESS))
                val body = cursor.getString(cursor.getColumnIndexOrThrow(Telephony.Sms.BODY))
                val date = cursor.getLong(cursor.getColumnIndexOrThrow(Telephony.Sms.DATE))
                list.add(SmsData(address, body, date))
            } while (cursor.moveToNext())
        }

        cursor?.close()

        getMmsMessages(this)
    }

    fun getMmsMessages(context: Context): List<SmsData> {
        val contentResolver = context.contentResolver

        val mmsCursor = contentResolver.query(
            Uri.parse("content://mms"),
            arrayOf("_id", "date"), // Only fetch MMS ID and date
            null,
            null,
            "date DESC"
        )

        if (mmsCursor != null && mmsCursor.moveToFirst()) {
            Log.e("TAG", "getMmsMessages: MMS")
            do {
                val mmsId = mmsCursor.getString(mmsCursor.getColumnIndexOrThrow("_id"))
                val date = mmsCursor.getLong(mmsCursor.getColumnIndexOrThrow("date"))

                // Fetch sender address for this MMS
                val address = getMmsSender(context, mmsId)

                // Fetch MMS message body
                val body = getMmsBody(context, mmsId)

                if (body.isNotEmpty()) {
                    list.add(SmsData(address, body, date*1000))
                }

            } while (mmsCursor.moveToNext())

            mmsCursor.close()
        }

        smsViewModel._smsList.value = list.sortedByDescending { it.timestamp }
        return list
    }

    fun getMmsSender(context: Context, mmsId: String): String {
        val uri = Uri.parse("content://mms/$mmsId/addr")
        val cursor = context.contentResolver.query(
            uri,
            arrayOf("address"),
            "type=137", // Type 137 = Sender
            null,
            null
        )
        return if (cursor != null && cursor.moveToFirst()) {
            val sender = cursor.getString(cursor.getColumnIndexOrThrow("address"))
            cursor.close()
            sender
        } else {
            "Unknown"
        }
    }


    fun getMmsBody(context: Context, mmsId: String): String {
        val uri = Uri.parse("content://mms/$mmsId/part")
        val cursor = context.contentResolver.query(
            uri,
            arrayOf("_id", "ct", "text"),
            "ct='text/plain'", // Get only text parts
            null,
            null
        )

        val body = StringBuilder()
        if (cursor != null && cursor.moveToFirst()) {
            do {
                val partId = cursor.getString(cursor.getColumnIndexOrThrow("_id"))
                val text = cursor.getString(cursor.getColumnIndexOrThrow("text"))

                if (text != null) {
                    body.append(text)
                } else {
                    // MMS text is stored in a separate file, read from it
                    body.append(readMmsTextFromFile(context, partId))
                }
            } while (cursor.moveToNext())
            cursor.close()
        }
        return body.toString()
    }


    fun readMmsTextFromFile(context: Context, partId: String): String {
        val uri = Uri.parse("content://mms/part/$partId")
        return try {
            val inputStream = context.contentResolver.openInputStream(uri)
            inputStream?.bufferedReader().use { it?.readText() } ?: ""
        } catch (e: Exception) {
            ""
        }
    }


    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 101 && grantResults.all { it == PackageManager.PERMISSION_GRANTED }) {
            smsViewModel.fetchAllSms(this)
        } else {
            Toast.makeText(this, "SMS Permission Denied", Toast.LENGTH_SHORT).show()
        }
    }

    private val mmsReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent?) {
            if (intent?.action == "android.provider.Telephony.WAP_PUSH_RECEIVED") {
                Log.d("MMS_RECEIVER", "MMS received dynamically")

            }
        }
    }

    override fun onResume() {
        super.onResume()
        val filterMMS = IntentFilter("android.provider.Telephony.WAP_PUSH_RECEIVED").apply {
            addDataType("application/vnd.wap.mms-message")  // MIME type filter
            priority = IntentFilter.SYSTEM_HIGH_PRIORITY  // Set high priority
        }

        registerReceiver(mmsReceiver, filterMMS)
    }

    override fun onPause() {
        super.onPause()
        unregisterReceiver(mmsReceiver)
    }

    override fun onDestroy() {
        super.onDestroy()
        LocalBroadcastManager.getInstance(this).unregisterReceiver(smsReceiver)
//        contentResolver.unregisterContentObserver(mmsObserver)
    }

    /*inner class MmsObserver(private val context: Context, handler: Handler) : ContentObserver(handler) {
        override fun onChange(selfChange: Boolean) {
            super.onChange(selfChange)
            Log.d("TAG", "New MMS detected!")
            fetchLatestMms(context)
        }

        private fun fetchLatestMms(context: Context) {
            val mmsList = getMmsMessages(context) // Call the function you used for fetching MMS
            Log.d("TAG", "Fetched MMS: ${mmsList.size}")

            // Here, update your RecyclerView with the latest data
            // Example: smsAdapter.updateData(mmsList)
        }
    }*/
}