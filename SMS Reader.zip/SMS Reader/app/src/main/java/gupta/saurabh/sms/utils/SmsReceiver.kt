package gupta.saurabh.sms.utils


import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.ContactsContract
import android.provider.Telephony
import android.util.Log
import androidx.localbroadcastmanager.content.LocalBroadcastManager

class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        Log.e("TAG", "onReceive: Hii 1", )
        if (Telephony.Sms.Intents.SMS_RECEIVED_ACTION == intent.action) {
            for (smsMessage in Telephony.Sms.Intents.getMessagesFromIntent(intent)) {
                val sender = smsMessage.originatingAddress ?: "Unknown"
                val messageBody = smsMessage.messageBody
                val timestamp = smsMessage.timestampMillis

                val smsIntent = Intent("SMS_RECEIVED").apply {
                    putExtra("sender", getContactName(context, sender))
                    putExtra("message", messageBody)
                    putExtra("timestamp", timestamp)
                }
                LocalBroadcastManager.getInstance(context).sendBroadcast(smsIntent)
            }
        }
    }

    fun getContactName(context: Context, phoneNumber: String): String {
        val normalizedNumber = normalizePhoneNumber(phoneNumber)

        val uri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
        val projection = arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER)

        context.contentResolver.query(uri, projection, null, null, null)?.use { cursor ->
            while (cursor.moveToNext()) {
                val contactName = cursor.getString(0)
                val contactNumber = normalizePhoneNumber(cursor.getString(1)) // Normalize saved number
                Log.d("DEBUG", "Checking: Saved - $contactNumber, Sender - $normalizedNumber")
                if (contactNumber.contains(normalizedNumber) || normalizedNumber.contains(contactNumber)) {
                    return contactName  // Return contact name if matched
                }
            }
        }
        return phoneNumber  // Return the original number if no match found
    }

    fun normalizePhoneNumber(number: String?): String {
        return number?.replace("\\s".toRegex(), "") ?: ""  // Remove all spaces
    }
}

