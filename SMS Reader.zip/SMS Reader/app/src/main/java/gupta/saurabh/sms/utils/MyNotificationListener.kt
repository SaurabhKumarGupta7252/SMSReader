package gupta.saurabh.sms.utils

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log

class MyNotificationListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName == "com.google.android.apps.messaging") {
            val extras = sbn.notification.extras
            val message = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()
            Log.d("TAG", "New RCS Message: $message")
        }
    }
}
